
open in vb6 ide
active the memory viewer window
press run
follow instructions on main form 