
builds project as a standalone exe for debugging