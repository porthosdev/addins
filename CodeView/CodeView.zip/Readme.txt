
Submitted on: 	5/27/2014 8:02:23 AM
By: 	Patrick de Groot  
Level: 	Advanced

Addin for Visual Basic 6 that displays all procedures/functions/variables/properties/constants 
of the currently selected form/module/class/control. This way you have a better overview of 
your code. It is a very usefull companion for the project explorer.

http://planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=75397&lngWId=1

I have added some right click options to treeview as well as a filter
textbox at the bottom of the form.  The filter also supports subtractive 
filterssuch as "-mouse click" which would hide anything with either of those 
strings in its name..minus must be first character

for the Find All form, the core of the search routine comes from the 
Code Fixer addin by Roger Gilchrist. 

