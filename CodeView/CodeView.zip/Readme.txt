
Submitted on: 	5/27/2014 8:02:23 AM
By: 	Patrick de Groot  
Level: 	Advanced

Addin for Visual Basic 6 that displays all procedures/functions/variables/properties/constants 
of the currently selected form/module/class/control. This way you have a better overview of 
your code. It is a very usefull companion for the project explorer.


http://planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=75397&lngWId=1
